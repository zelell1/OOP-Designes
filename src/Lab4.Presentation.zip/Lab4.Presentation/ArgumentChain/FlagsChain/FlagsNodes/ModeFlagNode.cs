using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemCommands.Builders;
using Itmo.ObjectOrientedProgramming.Lab4.Presentation.ArgumentChain.FlagArgumentsChain;

namespace Itmo.ObjectOrientedProgramming.Lab4.Presentation.ArgumentChain.FlagsChain.FlagsNodes;

public class ModeFlagNode<T> : BaseFlagChainParser<T> where T : IFileSystemBuilder<T>, IShowModeBuilder<T>
{
    private const string Keyword = "-m";

    public ModeFlagNode(IFlagArgumentsChainSelector argumentsChainSelector) : base(Keyword, argumentsChainSelector) { }
}