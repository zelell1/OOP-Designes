using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemCommands.Builders;
using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemCommands.Builders.ResultTypes;
using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemCommands.ResultTypes;
using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemComponents;
using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemComponents.FileSystemComponentsEnteties;
using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemComponentsVisitors;
using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemState;

namespace Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemCommands.FileSystemCommandEnteties;

public class TreeListCommand : IFileSystemCommand
{
    private readonly IFileSystemComponentVisitor _componentVisitor;

    private TreeListCommand(IFileSystemComponentVisitor componentVisitor)
    {
        _componentVisitor = componentVisitor;
    }

    public static ITreeListCommandBuilder Builder => new TreeListCommandBuilder();

    public FileSystemCommandResult Run(FileSystemSession session)
    {
        IFileSystemComponent comp = session.FileSystem.GetComponents(session.CurrentPath);

        if (comp is DirectoryFileSystemComponent dir)
        {
            _componentVisitor.Visit(dir);
            return new FileSystemCommandResult.Success(_componentVisitor.ToString());
        }

        return new FileSystemCommandResult.Failure(string.Empty);
    }

    public interface ITreeListCommandBuilder : IDepthBuilder<ITreeListCommandBuilder>,
                                               ICommandBuilder
    {
        ITreeListCommandBuilder AddVisitor(IFileSystemComponentVisitor componentVisitor);
    }

    private class TreeListCommandBuilder : ITreeListCommandBuilder
    {
        private IFileSystemComponentVisitor? _componentVisitor;

        private int _depth = 1;

        public ITreeListCommandBuilder AddDepth(int depth)
        {
            _depth = depth;
            return this;
        }

        public ITreeListCommandBuilder AddVisitor(IFileSystemComponentVisitor componentVisitor)
        {
            _componentVisitor = componentVisitor;
            return this;
        }

        public BuildCommandResult Build()
        {
            if (_componentVisitor is not null)
            {
                _componentVisitor.SetDepth(_depth);
                return new BuildCommandResult.Success(new TreeListCommand(_componentVisitor));
            }

            return new BuildCommandResult.Failure("No depth");
        }
    }
}