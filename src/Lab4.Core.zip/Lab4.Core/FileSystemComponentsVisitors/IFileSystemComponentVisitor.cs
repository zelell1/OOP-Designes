using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemComponents.FileSystemComponentsEnteties;

namespace Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemComponentsVisitors;

public interface IFileSystemComponentVisitor
{
    void Visit(FileFileSystemComponent components);

    void Visit(DirectoryFileSystemComponent component);

    void SetDepth(int depth);
}