using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemCommands.Builders;
using Itmo.ObjectOrientedProgramming.Lab4.Core.FileSystemCommands.Builders.ResultTypes;
using Itmo.ObjectOrientedProgramming.Lab4.Presentation.ArgumentChain.FlagsChain;
using Itmo.ObjectOrientedProgramming.Lab4.Presentation.ArgumentChain.ParametrsChain;
using Itmo.ObjectOrientedProgramming.Lab4.Presentation.CommandChain.ResultTypes;

namespace Itmo.ObjectOrientedProgramming.Lab4.Presentation.CommandChain;

public abstract class BaseChainParser : ICommandChainParser
{
    private readonly string _keyword;

    private readonly ICommandChainSelector _commandSubChain;

    private readonly IParametrsChainSelector _parametrsChain;

    private readonly IFlagChainSelector _flagChain;

    private ICommandChainParser? _next;

    protected BaseChainParser(
        string keyword,
        ICommandChainSelector chainSelector,
        IParametrsChainSelector parametrChain,
        IFlagChainSelector flagChain)
    {
        _keyword = keyword;
        _commandSubChain = chainSelector;
        _parametrsChain = parametrChain;
        _flagChain = flagChain;
    }

    public ParseBuildCommandResult Apply(IEnumerator<string> iterator)
    {
        if (iterator.Current != _keyword)
        {
            return CallNext(iterator);
        }

        iterator.MoveNext();
        ParseBuildCommandResult result = _commandSubChain.Apply(iterator);

        if (result is not ParseBuildCommandResult.Failure)
        {
            return result;
        }

        ICommandBuilder builder = CreateCommandBuilder();

        _parametrsChain.Apply(builder, iterator);

        _flagChain.Apply(builder, iterator);

        BuildCommandResult builderResult = builder.Build();

        if (builderResult is BuildCommandResult.Success success)
        {
            return new ParseBuildCommandResult.Success(success.Command);
        }

        return new ParseBuildCommandResult.Failure("Invalid command");
    }

    public ICommandChainParser AddNext(ICommandChainParser parser)
    {
        if (_next is null)
        {
            _next = parser;
        }
        else
        {
            _next.AddNext(parser);
        }

        return this;
    }

    protected abstract ICommandBuilder CreateCommandBuilder();

    private ParseBuildCommandResult CallNext(IEnumerator<string> iterator)
    {
        if (_next is null)
        {
            return new ParseBuildCommandResult.Failure("No command found");
        }

        return _next.Apply(iterator);
    }
}